using Cirrious.CrossCore.Plugins;

namespace CallForm.iOS.Bootstrap
{
    public class SqlitePluginBootstrap
        : MvxLoaderPluginBootstrapAction<Cirrious.MvvmCross.Plugins.Sqlite.PluginLoader, Cirrious.MvvmCross.Plugins.Sqlite.Touch.Plugin>
    {
    }
}
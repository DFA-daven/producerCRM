using Cirrious.CrossCore.Plugins;

namespace CallForm.iOS.Bootstrap
{
    public class VisibilityPluginBootstrap
        : MvxLoaderPluginBootstrapAction<Cirrious.MvvmCross.Plugins.Visibility.PluginLoader, Cirrious.MvvmCross.Plugins.Visibility.Touch.Plugin>
    {
    }
}
using Cirrious.CrossCore.Plugins;

namespace CallForm.iOS.Bootstrap
{
    public class LocationPluginBootstrap
        : MvxLoaderPluginBootstrapAction<Cirrious.MvvmCross.Plugins.Location.PluginLoader, Cirrious.MvvmCross.Plugins.Location.Touch.Plugin>
    {
    }
}
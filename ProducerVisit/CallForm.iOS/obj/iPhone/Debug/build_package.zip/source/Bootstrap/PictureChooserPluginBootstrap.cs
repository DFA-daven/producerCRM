using Cirrious.CrossCore.Plugins;

namespace CallForm.iOS.Bootstrap
{
    public class PictureChooserPluginBootstrap
        : MvxLoaderPluginBootstrapAction<Cirrious.MvvmCross.Plugins.PictureChooser.PluginLoader, Cirrious.MvvmCross.Plugins.PictureChooser.Touch.Plugin>
    {
    }
}
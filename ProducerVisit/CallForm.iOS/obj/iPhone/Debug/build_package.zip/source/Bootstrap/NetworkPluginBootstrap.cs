using Cirrious.CrossCore.Plugins;

namespace CallForm.iOS.Bootstrap
{
    public class NetworkPluginBootstrap
        : MvxLoaderPluginBootstrapAction<Cirrious.MvvmCross.Plugins.Network.PluginLoader, Cirrious.MvvmCross.Plugins.Network.Touch.Plugin>
    {
    }
}